<?php

return [
    'taxes' => [
        'index' => 'Index Tax',
        'create' => 'Create Tax',
        'edit' => 'Edit Tax',
        'destroy' => 'Delete Tax',
    ],
];
