<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-products">
        <h4><?php echo e(trans('admin::dashboard.total_products')); ?></h4>

        <i class="fa fa-cubes" aria-hidden="true"></i>
        <span class="pull-right"><?php echo e($totalProducts); ?></span>
    </div>
</div>
<?php /**PATH /home/mordezsc/public_html/tool-mex/Modules/Admin/Resources/views/dashboard/grids/total_products.blade.php ENDPATH**/ ?>