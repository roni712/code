<div class="row">
    <div class="col-md-8">
        <?php echo e(Form::checkbox('maintenance_mode', trans('setting::attributes.maintenance_mode'), trans('setting::settings.form.put_the_application_into_maintenance_mode'), $errors, $settings)); ?>

        <?php echo e(Form::textarea('allowed_ips', trans('setting::attributes.allowed_ips'), $errors, $settings, ['placeholder' => trans('setting::settings.form.ip_addreses_seperated_in_new_line')])); ?>

    </div>
</div>
<?php /**PATH /home/mordezsc/public_html/tool-mex/Modules/Setting/Resources/views/admin/settings/tabs/maintenance.blade.php ENDPATH**/ ?>