<?php echo e(Form::password('currency_data_feed_api_key', trans('setting::attributes.currency_data_feed_api_key'), $errors, $settings, ['required' => true])); ?>

<?php /**PATH /home/mordezsc/public_html/tool-mex/Modules/Setting/Resources/views/admin/settings/partials/currency_rate_exchange_services/currency_data_feed.blade.php ENDPATH**/ ?>