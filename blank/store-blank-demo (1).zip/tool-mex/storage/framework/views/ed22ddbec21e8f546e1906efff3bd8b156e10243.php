<?php $__env->startSection('title', trans('core::messages.service_unavailable')); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('message', __($exception->getMessage() ?: trans('core::messages.in_maintenance'))); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mordezsc/public_html/tool-mex/resources/views/errors/503.blade.php ENDPATH**/ ?>