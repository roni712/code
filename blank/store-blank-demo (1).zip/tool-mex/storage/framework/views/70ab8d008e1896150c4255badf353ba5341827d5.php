<?php echo e(Form::password('fixer_access_key', trans('setting::attributes.fixer_access_key'), $errors, $settings, ['required' => true])); ?>

<?php /**PATH /home/mordezsc/public_html/tool-mex/Modules/Setting/Resources/views/admin/settings/partials/currency_rate_exchange_services/fixer.blade.php ENDPATH**/ ?>