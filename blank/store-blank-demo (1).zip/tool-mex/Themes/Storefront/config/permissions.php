<?php

return [
    'admin.storefront' => [
        'edit' => 'storefront::permissions.storefront.edit',
    ],
];
