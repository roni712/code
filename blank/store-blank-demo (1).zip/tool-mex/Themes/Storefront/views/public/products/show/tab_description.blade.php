<div id="description" class="tab-pane description" :class="{ active: activeTab === 'description' }">
    {!! $product->description !!}
</div>
