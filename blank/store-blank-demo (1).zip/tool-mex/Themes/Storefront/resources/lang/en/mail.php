<?php

return [
    'hello' => 'Hello :name!',
    'all_rights_reserved' => 'All rights reserved.',
];
