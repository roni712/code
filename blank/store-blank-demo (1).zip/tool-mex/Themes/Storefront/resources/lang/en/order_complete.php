<?php

return [
    'order_placed' => 'Order Placed!',
    'your_order_has_been_placed' => 'Your order has been placed. Your order ID is: <b>:id</b>',
];
