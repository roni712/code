<?php

return [
    'storefront' => 'Storefront',
];
