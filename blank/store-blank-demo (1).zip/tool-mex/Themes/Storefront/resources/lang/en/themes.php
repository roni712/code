<?php

return [
    'blue' => 'Blue',
    'bondi-blue' => 'Bondi Blue',
    'cornflower' => 'Cornflower',
    'violet' => 'Violet',
    'red' => 'Red',
    'yellow' => 'Yellow',
    'orange' => 'Orange',
    'green' => 'Green',
    'pink' => 'Pink',
    'black' => 'Black',
    'indigo' => 'Indigo',
    'magenta' => 'Magenta',
    'custom_color' => 'Custom Color',
];
