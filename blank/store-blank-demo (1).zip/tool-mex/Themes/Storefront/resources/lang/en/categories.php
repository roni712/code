<?php

return [
    'all_categories' => 'All Categories',
    'no_category_found' => 'Opps! No category found.',
];
