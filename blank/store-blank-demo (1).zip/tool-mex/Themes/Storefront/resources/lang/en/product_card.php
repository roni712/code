<?php

return [
    'out_of_stock' => 'Out of Stock',
    'new' => 'New',
    'add_to_cart' => 'ADD TO CART',
    'view_options' => 'VIEW OPTIONS',
    'compare' => 'Compare',
    'wishlist' => 'Wishlist',
    'available' => 'Available:',
    'sold' => 'Sold:',
    'years' => 'Years',
    'months' => 'Months',
    'weeks' => 'Weeks',
    'days' => 'Days',
    'hours' => 'Hours',
    'minutes' => 'Minutes',
    'seconds' => 'Seconds',
];
