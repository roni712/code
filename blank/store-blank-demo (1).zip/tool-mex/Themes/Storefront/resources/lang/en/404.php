<?php

return [
    '404' => '404',
    'page_not_found' => 'Oops! Page Not Found.',
    'unable_to_find_the_page' => 'Sorry but we are unable to find the page that you are looking for.',
    'back_to_home' => 'BACK TO HOME',
];
