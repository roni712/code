<?php

return [
    'the_given_data_was_invalid' => 'The given data was invalid.',
    'service_unavailable' => 'Service Unavailable',
    'in_maintenance' => 'Sorry, we are doing some maintenance.',
    'mail_is_not_configured' => 'Mail is not configured properly.',
];
