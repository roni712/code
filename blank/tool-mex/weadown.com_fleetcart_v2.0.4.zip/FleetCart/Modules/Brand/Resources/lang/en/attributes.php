<?php

return [
    'name' => 'Name',
    'slug' => 'URL',
    'is_active' => 'Status',
];
