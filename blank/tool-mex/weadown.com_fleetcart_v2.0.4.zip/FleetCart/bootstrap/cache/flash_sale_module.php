<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FlashSale\\Providers\\FlashSaleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FlashSale\\Providers\\FlashSaleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);