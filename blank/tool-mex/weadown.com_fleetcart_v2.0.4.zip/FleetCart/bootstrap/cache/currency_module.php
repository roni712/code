<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Currency\\Providers\\CurrencyServiceProvider',
    1 => 'Modules\\Currency\\Providers\\EventServiceProvider',
    2 => 'Modules\\Currency\\Providers\\CurrencyExchangeRateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Currency\\Providers\\CurrencyServiceProvider',
    1 => 'Modules\\Currency\\Providers\\EventServiceProvider',
    2 => 'Modules\\Currency\\Providers\\CurrencyExchangeRateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);