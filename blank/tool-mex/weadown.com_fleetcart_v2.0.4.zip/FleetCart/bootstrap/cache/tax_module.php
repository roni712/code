<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tax\\Providers\\TaxServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tax\\Providers\\TaxServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);