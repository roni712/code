<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
    1 => 'Modules\\User\\Providers\\EventServiceProvider',
    2 => 'Modules\\User\\Providers\\SocialLoginServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
    1 => 'Modules\\User\\Providers\\EventServiceProvider',
    2 => 'Modules\\User\\Providers\\SocialLoginServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);